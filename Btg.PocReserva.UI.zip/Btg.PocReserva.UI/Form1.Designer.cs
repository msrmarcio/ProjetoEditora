﻿namespace Btg.PocReserva.UI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtgLogin = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtgLogin
            // 
            this.BtgLogin.FlatAppearance.BorderSize = 0;
            this.BtgLogin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BtgLogin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.BtgLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtgLogin.Location = new System.Drawing.Point(0, 0);
            this.BtgLogin.Name = "BtgLogin";
            this.BtgLogin.Size = new System.Drawing.Size(88, 24);
            this.BtgLogin.TabIndex = 0;
            this.BtgLogin.Text = "Authentication";
            this.BtgLogin.UseVisualStyleBackColor = true;
            this.BtgLogin.Click += new System.EventHandler(this.BtgLogin_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 56);
            this.Controls.Add(this.BtgLogin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtgLogin;
    }
}

