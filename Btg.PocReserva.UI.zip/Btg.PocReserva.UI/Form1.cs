﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web;
using System.Collections.Specialized;

namespace Btg.PocReserva.UI
{
    public partial class Form1 : Form
    {
        string user = "30213588889";
        string password = "Val090482";
        string url = @"https://associado.afpesp.org.br/json/Login.aspx";
        string urlFlexReserva = @"https://www.flexreserva.org.br/json/login.aspx";
        string urlDisponibilidade;
        CookieAwareWebClient client;
        List<string> lstIdReservas;

        public Form1()
        {
            InitializeComponent();

            lstIdReservas = new List<string>();
            for (int i = 0; i < 18; i++)
            {
                int id = 4001 + i;
                lstIdReservas.Add(id.ToString());
            }
            lstIdReservas.Add("4020");
            this.BackColor = Color.White;
            Application.DoEvents();
        }

        private void BtgLogin_Click(object sender, EventArgs e)
        {
            client = new CookieAwareWebClient();
            NameValueCollection param = new NameValueCollection();
            param.Add("ma", "30213588889");
            param.Add("pwd", "Val090482");
            client.Login(urlFlexReserva, param);

            // get toddos
            GetDisponibilidade();

            RetornarDisponibilidade();


            client.RetornarPeriodos();
            client.RetornaHoteis();
        }

        private void RetornarDisponibilidade()
        {
            NameValueCollection param = new NameValueCollection();
            string strDataChegada = new DateTime(2019, 12, 27).ToShortDateString();
            string _ = "1569254298528";
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            dictionary.Add("strDataChegada", new DateTime(2019, 12, 27).ToShortDateString());
            dictionary.Add("_", "1569254298528");

            param.Add("strDataChegada", strDataChegada);
            param.Add("_", _);
            urlDisponibilidade = @"https://4005.afpesp.org.br/RetornaDisponibilidade?callback=RetornaDisponibilidade&strDataChegada=27%2F12%2F2019&_=1569270381462";

            client.HttpPostRequest(urlDisponibilidade, dictionary);
            client.Disponibilidade(urlDisponibilidade, param);
        }

        private void GetDisponibilidade()
        {
            NameValueCollection param = new NameValueCollection();
            string strDataChegada = new DateTime(2019, 12, 22).ToShortDateString();
            string _ = "1569254298528";
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            dictionary.Add("strDataChegada", new DateTime(2019, 12, 22).ToShortDateString());
            dictionary.Add("_", "1569254298528");

            param.Add("strDataChegada", strDataChegada);
            param.Add("_", _);
            urlDisponibilidade = @"https://4001.afpesp.org.br/RetornaDisponibilidade?callback=RetornaDisponibilidade&strDataChegada=27%2F12%2F2019&_=1569254155737";

            dictionary = new Dictionary<string, string>();
            dictionary.Add("strDataChegada", new DateTime(2019, 12, 27).ToShortDateString());
            dictionary.Add("_", "1569254298528");

            foreach (var item in lstIdReservas)
            {
                url = string.Format(@"https://{0}.afpesp.org.br/RetornaDisponibilidade?callback=RetornaDisponibilidade&strDataChegada=27%2F12%2F2019&_=1569254155737", item);
                client.Disponibilidade(url, param);
            }

            this.BackColor = Color.Red;
            Application.DoEvents();
        }
    }
}
